plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fouad.voice"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.fouad.voice"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

val assetsDir = file("src/main/assets")
val downloadFonts = tasks.register("downloadFonts") {
    doLast {
        assetsDir.mkdirs()
        listOf("Tajawal-Medium.ttf", "Tajawal-Black.ttf").forEach { f ->
            val out = File(assetsDir, f)
            if (!out.exists()) {
                try {
                    java.net.URL("https://github.com/google/fonts/raw/main/ofl/tajawal/$f")
                        .openStream().use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                } catch (e: Exception) {
                    println("font download failed: $f")
                }
            }
        }
    }
}
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }
    .configureEach { dependsOn(downloadFonts) }
