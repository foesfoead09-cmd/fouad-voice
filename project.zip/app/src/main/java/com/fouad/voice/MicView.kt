package com.fouad.voice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class MicView(c: Context, var tint: Int = Color.WHITE) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = tint
        p.style = Paint.Style.FILL
        val cw = w * 0.32f
        cv.drawRoundRect(w / 2 - cw / 2, h * 0.06f, w / 2 + cw / 2, h * 0.56f, cw / 2, cw / 2, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.07f
        p.strokeCap = Paint.Cap.ROUND
        cv.drawArc(w * 0.20f, h * 0.26f, w * 0.80f, h * 0.74f, 0f, 180f, false, p)
        cv.drawLine(w / 2, h * 0.74f, w / 2, h * 0.92f, p)
        cv.drawLine(w * 0.36f, h * 0.92f, w * 0.64f, h * 0.92f, p)
    }
}
