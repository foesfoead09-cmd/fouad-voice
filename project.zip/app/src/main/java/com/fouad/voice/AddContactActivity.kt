package com.fouad.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AddContactActivity : Activity() {
    private lateinit var nameEt: EditText
    private lateinit var phoneEt: EditText
    private var wasOn = false

    private val brown = Color.parseColor("#4A2C11")
    private val green = Color.parseColor("#4B8E6B")
    private val gray = Color.parseColor("#6B5B4F")

    private val words = mapOf(
        "صفر" to "0", "زيرو" to "0", "واحد" to "1", "وحد" to "1",
        "جوج" to "2", "زوج" to "2", "اثنين" to "2", "اتنين" to "2",
        "تلاتة" to "3", "ثلاثة" to "3", "تلاته" to "3",
        "ربعة" to "4", "اربعة" to "4", "أربعة" to "4",
        "خمسة" to "5", "خمسه" to "5", "ستة" to "6", "سته" to "6",
        "سبعة" to "7", "سبعه" to "7", "تمنية" to "8", "ثمانية" to "8", "تمانية" to "8",
        "تسعود" to "9", "تسعة" to "9", "تسعه" to "9"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val fReg: Typeface? by lazy {
        try { Typeface.createFromAsset(assets, "Tajawal-Medium.ttf") } catch (e: Exception) { null }
    }
    private val fBold: Typeface? by lazy {
        try { Typeface.createFromAsset(assets, "Tajawal-Black.ttf") } catch (e: Exception) { null }
    }

    private fun shape(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(dp(stroke), sc)
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) {
            if (fBold != null) typeface = fBold else setTypeface(null, Typeface.BOLD)
        } else if (fReg != null) typeface = fReg
    }

    private fun digits(t: String): String {
        val sb = StringBuilder()
        for (w in t.split(" ", ",", "،")) {
            val m = words[w]
            if (m != null) sb.append(m)
            else sb.append(w.filter { it.isDigit() }.map { Character.getNumericValue(it).toString() }.joinToString(""))
        }
        return sb.toString()
    }

    private fun label(text: String, req: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv(text, 26f, brown, true).apply { gravity = Gravity.START },
            LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(MicView(this, green).apply { setOnClickListener { voice(req) } },
            LinearLayout.LayoutParams(dp(30), dp(30)))
        return row
    }

    private fun field(hint: String, req: Int, phone: Boolean): Pair<LinearLayout, EditText> {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))
        box.background = shape(Color.parseColor("#F3EBDD"), 18, 2, Color.parseColor("#CFC9A0"))
        box.addView(MicView(this, green).apply { setOnClickListener { voice(req) } },
            LinearLayout.LayoutParams(dp(28), dp(28)))
        val et = EditText(this).apply {
            this.hint = hint
            textSize = 18f
            setTextColor(brown)
            setHintTextColor(gray)
            background = null
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            if (fReg != null) typeface = fReg
            if (phone) inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        val elp = LinearLayout.LayoutParams(0, dp(52), 1f)
        elp.marginStart = dp(10)
        box.addView(et, elp)
        return Pair(box, et)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        wasOn = VoiceService.on
        if (wasOn) stopService(Intent(this, VoiceService::class.java))

        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(PatternView(this), ViewGroup.LayoutParams(-1, -1))

        val b = dp(28)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.setMargins(dp(22), dp(34), dp(22), dp(30))
        root.addView(scroll, lp)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(0, dp(6), 0, dp(10))
        scroll.addView(card, ViewGroup.LayoutParams(-1, -2))

        val back = LinearLayout(this)
        back.orientation = LinearLayout.HORIZONTAL
        back.gravity = Gravity.CENTER_VERTICAL
        back.setOnClickListener { finish() }
        back.addView(tv("رجوع", 22f, green, true))
        back.addView(tv("←", 28f, green, true).apply { setPadding(dp(8), 0, 0, 0) })
        card.addView(back, LinearLayout.LayoutParams(-2, -2))

        card.addView(tv("إدخال المعلومات", 32f, brown, true).apply {
            gravity = Gravity.START
            setPadding(0, dp(14), 0, 0)
        })
        card.addView(tv("تحدث لإدخال الاسم ورقم الهاتف", 15f, gray).apply {
            gravity = Gravity.START
            setPadding(0, dp(2), 0, dp(18))
        })

        card.addView(label("الاسم:", 1))
        val (nb, ne) = field("اضغط وتحدث بالاسم...", 1, false)
        nameEt = ne
        val nlp = LinearLayout.LayoutParams(-1, -2)
        nlp.topMargin = dp(6); nlp.bottomMargin = dp(16)
        card.addView(nb, nlp)

        card.addView(label("رقم الهاتف:", 2))
        val (pb, pe) = field("اضغط وتحدث برقم الهاتف...", 2, true)
        phoneEt = pe
        val plp = LinearLayout.LayoutParams(-1, -2)
        plp.topMargin = dp(6); plp.bottomMargin = dp(22)
        card.addView(pb, plp)

        val next = LinearLayout(this)
        next.orientation = LinearLayout.HORIZONTAL
        next.gravity = Gravity.CENTER
        next.background = shape(green, 40)
        next.elevation = dp(6).toFloat()
        next.setOnClickListener { save() }
        next.addView(tv("التالي", 26f, Color.WHITE, true))
        val circle = tv("→", 24f, green, true)
        circle.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        val clp = LinearLayout.LayoutParams(dp(40), dp(40))
        clp.marginStart = dp(12)
        next.addView(circle, clp)
        card.addView(next, LinearLayout.LayoutParams(-1, dp(68)))

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER
        foot.addView(MicView(this, green), LinearLayout.LayoutParams(dp(18), dp(18)))
        foot.addView(tv("يمكنك التحدث بوضوح ليتم التسجيل تلقائياً", 13f, gray).apply {
            setPadding(dp(6), 0, 0, 0)
        })
        val flp = LinearLayout.LayoutParams(-1, -2)
        flp.topMargin = dp(16)
        card.addView(foot, flp)

        setContentView(root)
    }

    private fun save() {
        val name = nameEt.text.toString().trim()
        val num = phoneEt.text.toString().filter { it.isDigit() || it == '+' }
        if (name.isEmpty() || num.length < 8) {
            Toast.makeText(this, "دخل السمية والنمرة", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences("contacts", MODE_PRIVATE).edit().putString(name, num).apply()
        Toast.makeText(this, "تسجل: $name", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun voice(req: Int) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != 0) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9)
            return
        }
        try {
            startActivityForResult(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, if (req == 1) "قول السمية" else "قول النمرة"),
                req
            )
        } catch (e: Exception) {
            Toast.makeText(this, "التعرف على الصوت ما كايناش", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        if (req == 1) nameEt.setText(t) else phoneEt.setText(digits(t))
    }

    override fun onDestroy() {
        super.onDestroy()
        if (wasOn && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0)
            startForegroundService(Intent(this, VoiceService::class.java))
    }
}
