package com.fouad.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import java.util.Locale

class VoiceService : Service() {
    companion object { @Volatile var on = false }

    private enum class S { IDLE, ASK_NAME, ASK_PHONE, CONFIRM_ADD, CONFIRM_CALL }

    private var state = S.IDLE
    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var gen = 0
    private var pName = ""
    private var pPhone = ""
    private val prefs by lazy { getSharedPreferences("contacts", MODE_PRIVATE) }

    private val digitWords = mapOf(
        "صفر" to "0", "زيرو" to "0", "واحد" to "1", "وحد" to "1",
        "جوج" to "2", "زوج" to "2", "اثنين" to "2", "اتنين" to "2",
        "تلاتة" to "3", "ثلاثة" to "3", "تلاته" to "3",
        "ربعة" to "4", "اربعة" to "4", "أربعة" to "4",
        "خمسة" to "5", "خمسه" to "5", "ستة" to "6", "سته" to "6",
        "سبعة" to "7", "سبعه" to "7", "تمنية" to "8", "ثمانية" to "8", "تمانية" to "8",
        "تسعود" to "9", "تسعة" to "9", "تسعه" to "9"
    )
    private val yes = setOf("ايه", "إيه", "أيه", "اه", "أه", "نعم", "واه", "واخا", "صحيح", "اي", "ايوا", "إيوا")
    private val no = setOf("لا", "لأ", "لاا", "ماشي", "غلط", "لالا")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (on) return START_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "المساعد", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "v")
            .setContentTitle("مساعد فؤاد شاعل")
            .setContentText("قول: ألو فؤاد")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        on = true
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ar")
                say("المساعد شاعل. قول: ألو فؤاد")
            } else listen()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        on = false
        gen++
        rec?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun norm(s: String) = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        .replace("ؤ", "و").replace("ة", "ه").trim()

    private fun say(text: String, delayListen: Long = 0) {
        gen++
        rec?.cancel()
        val done = { h.postDelayed({ listen() }, delayListen) }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { done() }
            override fun onError(u: String?) { done() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (!on) return
        val my = ++gen
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    if (my != gen) return
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) listen() else handle(t)
                }
                override fun onError(e: Int) {
                    if (my != gen) return
                    h.postDelayed({ if (my == gen) listen() }, 700)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-MA"))
        }
    }

    private fun toDigits(t: String): String {
        val sb = StringBuilder()
        for (w in t.split(" ", ",", "،")) {
            val m = digitWords[w] ?: digitWords[norm(w)]
            if (m != null) sb.append(m)
            else sb.append(w.filter { it.isDigit() }.map { Character.getNumericValue(it).toString() }.joinToString(""))
        }
        return sb.toString()
    }

    private fun isYes(t: String) = t.split(" ").map { norm(it) }.any { it in yes.map(::norm) }
    private fun isNo(t: String) = t.split(" ").map { norm(it) }.any { it in no.map(::norm) }

    private fun callNow(num: String, name: String) {
        state = S.IDLE
        gen++
        rec?.cancel()
        try {
            getSystemService(TelecomManager::class.java)
                .placeCall(Uri.fromParts("tel", num, null), Bundle())
            h.postDelayed({ listen() }, 10000)
        } catch (e: SecurityException) { say("ما عنديش الإذن ديال الاتصال") }
    }

    private fun handle(raw: String) {
        val t = norm(raw)
        when (state) {
            S.IDLE -> {
                // "ألو ماما" => اتصال مباشر بلا تأكيد
                if (t.contains("الو")) {
                    val direct = prefs.all.keys.firstOrNull { t.contains(norm(it)) }
                    if (direct != null) {
                        val num = prefs.getString(direct, "") ?: ""
                        if (num.isNotEmpty()) { callNow(num, direct); return }
                    }
                }
                if (!(t.contains("فواد") || t.contains("فود"))) { listen(); return }
                if (t.contains("زيد") || t.contains("سجل") || t.contains("جديد")) {
                    state = S.ASK_NAME
                    say("شنو هي سمية الشخص؟")
                } else if (t.contains("عيط")) {
                    val hit = prefs.all.keys.firstOrNull { t.contains(norm(it)) }
                    if (hit == null) say("ما لقيتش هاد السمية. قول: ألو فؤاد، زيد جهة")
                    else {
                        pName = hit; pPhone = prefs.getString(hit, "") ?: ""
                        state = S.CONFIRM_CALL
                        say("واش نعيط لـ $hit؟ قول إيه ولا لا")
                    }
                } else say("قول: عيط لـ وسمية الشخص. ولا: زيد جهة")
            }
            S.ASK_NAME -> {
                pName = raw.trim(); state = S.ASK_PHONE
                say("مزيان. شنو هي نمرتو؟")
            }
            S.ASK_PHONE -> {
                val d = toDigits(raw)
                if (d.length < 8) say("ما فهمتش النمرة. عاود قولها")
                else {
                    pPhone = d; state = S.CONFIRM_ADD
                    say("السمية $pName، والنمرة ${d.toList().joinToString(" ")}. واش صحيح؟ قول إيه ولا لا")
                }
            }
            S.CONFIRM_ADD -> {
                if (isNo(t)) { state = S.IDLE; say("واخا، تلغات العملية") }
                else if (isYes(t)) {
                    prefs.edit().putString(pName, pPhone).apply()
                    state = S.IDLE; say("تسجلات. دابا قول: ألو فؤاد، عيط لـ $pName")
                } else say("قول إيه ولا لا")
            }
            S.CONFIRM_CALL -> {
                if (isNo(t)) { state = S.IDLE; say("واخا، ما عيطتش") }
                else if (isYes(t)) {
                    state = S.IDLE
                    callNow(pPhone, pName)
                } else say("قول إيه ولا لا")
            }
        }
    }
}
