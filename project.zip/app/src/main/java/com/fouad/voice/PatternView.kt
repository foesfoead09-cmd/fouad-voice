package com.fouad.voice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class PatternView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private fun star(cv: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        for (i in 0 until 16) {
            val a = i * Math.PI / 8 - Math.PI / 2
            val rr = if (i % 2 == 0) r else r * 0.72f
            val x = (cx + rr * Math.cos(a)).toFloat()
            val y = (cy + rr * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        cv.drawPath(path, p)
    }

    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.parseColor("#EFE9DD"))
        val s = 70 * resources.displayMetrics.density
        var y = 0f
        var row = 0
        while (y < height + s) {
            var x = if (row % 2 == 0) 0f else s / 2
            var col = 0
            while (x < width + s) {
                p.color = Color.parseColor(if ((row + col) % 2 == 0) "#4B8E6B" else "#C77B58")
                p.alpha = 170
                star(cv, x, y, s * 0.33f)
                p.color = Color.parseColor("#EFE9DD")
                cv.drawCircle(x, y, s * 0.09f, p)
                x += s
                col++
            }
            y += s * 0.5f
            row++
        }
    }
}
