package com.fouad.voice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

class PatternView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val cream = Color.parseColor("#FBF6EA")
    private val green = Color.parseColor("#4B8E6B")
    private val clay = Color.parseColor("#C77B58")

    private fun star(cv: Canvas, cx: Float, cy: Float, r: Float, rot: Double) {
        path.reset()
        for (i in 0 until 16) {
            val a = i * Math.PI / 8 + rot - Math.PI / 2
            val rr = if (i % 2 == 0) r else r * 0.70f
            val x = (cx + rr * Math.cos(a)).toFloat()
            val y = (cy + rr * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        cv.drawPath(path, p)
    }

    private val sage = Color.parseColor("#A8C3A0")
    private val terra = Color.parseColor("#D9A27F")
    private val sage2 = Color.parseColor("#6FA283")
    private val terra2 = Color.parseColor("#C77B58")

    private fun corner(cv: Canvas, ox: Float, oy: Float, sx: Float, sy: Float, t: Float) {
        val n = 5
        for (i in 0 until n) for (j in 0 until n - i) {
            val k = i + j
            val x = ox + sx * (t / 2 + i * t)
            val y = oy + sy * (t / 2 + j * t)
            val f = 1f - k * 0.15f
            val even = k % 2 == 0
            p.color = if (even) sage else terra
            p.alpha = (255 * f).toInt().coerceIn(70, 255)
            star(cv, x, y, t * 0.5f * f, 0.0)
            p.color = if (even) terra2 else sage2
            p.alpha = (255 * f).toInt().coerceIn(70, 255)
            star(cv, x, y, t * 0.30f * f, Math.PI / 8)
            p.color = Color.parseColor("#FAF0E3")
            p.alpha = 255
            cv.drawCircle(x, y, t * 0.08f * f, p)
        }
    }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val t = 24 * d
        cv.drawColor(Color.parseColor("#FAF0E3"))
        p.style = Paint.Style.FILL
        corner(cv, 0f, 0f, 1f, 1f, t)
        corner(cv, w, 0f, -1f, 1f, t)
        corner(cv, 0f, h, 1f, -1f, t)
        corner(cv, w, h, -1f, -1f, t)
    }
}
