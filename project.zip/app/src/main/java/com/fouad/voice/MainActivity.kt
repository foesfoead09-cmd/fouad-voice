package com.fouad.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button

class MainActivity : Activity() {
    private lateinit var btn: Button

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        btn = Button(this).apply {
            textSize = 44f
            setTextColor(Color.WHITE)
            setOnClickListener { toggle() }
        }
        setContentView(btn)
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        if (VoiceService.on) {
            stopService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
        } else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            startForegroundService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
        }
    }

    private fun refresh() {
        if (VoiceService.on) {
            btn.text = "المساعد شاعل\n(اضغط باش توقفو)"
            btn.setBackgroundColor(Color.parseColor("#2E7D32"))
        } else {
            btn.text = "تشغيل"
            btn.setBackgroundColor(Color.parseColor("#D32F2F"))
        }
    }
}
