package com.fouad.voice

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var mic: TextView
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("contacts", MODE_PRIVATE) }

    private val brown = Color.parseColor("#4A2C11")
    private val green = Color.parseColor("#4B8E6B")
    private val red = Color.parseColor("#D32F2F")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(dp(stroke), sc)
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(PatternView(this), ViewGroup.LayoutParams(-1, -1))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.background = shape(Color.parseColor("#F7FDFBF7"), 28, 2, green)
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.setMargins(dp(16), dp(40), dp(16), dp(32))
        root.addView(scroll, lp)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(18), dp(24), dp(18), dp(24))
        scroll.addView(card, ViewGroup.LayoutParams(-1, -2))

        card.addView(tv("مساعد فؤاد", 32f, brown, true))
        card.addView(tv("قول: ألو + سمية الشخص", 17f, Color.parseColor("#6B5B4F")).apply {
            setPadding(0, dp(4), 0, dp(20))
        })

        mic = tv("🎤", 72f, Color.WHITE).apply { setOnClickListener { toggle() } }
        card.addView(mic, LinearLayout.LayoutParams(dp(190), dp(190)))

        status = tv("", 20f, red, true).apply { setPadding(0, dp(14), 0, dp(6)) }
        card.addView(status)

        card.addView(tv("الأشخاص المسجلين", 21f, brown, true).apply {
            setPadding(0, dp(24), 0, dp(10))
        })
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        card.addView(list, LinearLayout.LayoutParams(-1, -2))

        val add = Button(this).apply {
            text = "＋ زيد شخص"
            textSize = 20f
            setTextColor(Color.WHITE)
            background = shape(green, 30)
            setOnClickListener { addDialog() }
        }
        val alp = LinearLayout.LayoutParams(-1, dp(58))
        alp.topMargin = dp(10)
        card.addView(add, alp)

        card.addView(tv("ولا بالصوت: قول «ألو فؤاد، زيد جهة»", 14f, Color.parseColor("#6B5B4F")).apply {
            setPadding(0, dp(14), 0, 0)
        })

        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        if (VoiceService.on) {
            stopService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
        } else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            startForegroundService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
        }
    }

    private fun addDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val n = EditText(this).apply { hint = "السمية (مثلا: ماما)" }
        val ph = EditText(this).apply {
            hint = "النمرة"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        box.addView(n)
        box.addView(ph)
        AlertDialog.Builder(this)
            .setTitle("شخص جديد")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val name = n.text.toString().trim()
                val num = ph.text.toString().filter { it.isDigit() || it == '+' }
                if (name.isNotEmpty() && num.length >= 8) {
                    prefs.edit().putString(name, num).apply()
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun refresh() {
        val on = VoiceService.on
        mic.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) green else red)
        }
        status.setTextColor(if (on) green else red)
        status.text = if (on) "المساعد شاعل\nقول: ألو ماما" else "اضغط باش تشغل المساعد"

        list.removeAllViews()
        val keys = prefs.all.keys.sorted()
        if (keys.isEmpty()) {
            list.addView(tv("ما كاين حتى شخص مسجل", 16f, Color.parseColor("#6B5B4F")))
        }
        for (k in keys) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            row.background = shape(Color.parseColor("#F3EFE6"), 14, 1, Color.parseColor("#DCD6CC"))
            row.addView(tv(k, 22f, brown, true).apply { gravity = Gravity.START },
                LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv(prefs.getString(k, "") ?: "", 16f, Color.parseColor("#6B5B4F")))
            row.addView(tv("✕", 22f, red, true).apply {
                setPadding(dp(14), 0, 0, 0)
                setOnClickListener { prefs.edit().remove(k).apply(); refresh() }
            })
            val rlp = LinearLayout.LayoutParams(-1, -2)
            rlp.bottomMargin = dp(8)
            list.addView(row, rlp)
        }
    }
}
