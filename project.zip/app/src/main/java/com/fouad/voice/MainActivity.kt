package com.fouad.voice

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("contacts", MODE_PRIVATE) }

    private val brown = Color.parseColor("#4A2C11")
    private val green = Color.parseColor("#4B8E6B")
    private val red = Color.parseColor("#D32F2F")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(dp(stroke), sc)
    }

    private val fReg: Typeface? by lazy {
        try { Typeface.createFromAsset(assets, "Tajawal-Medium.ttf") } catch (e: Exception) { null }
    }
    private val fBold: Typeface? by lazy {
        try { Typeface.createFromAsset(assets, "Tajawal-Black.ttf") } catch (e: Exception) { null }
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) {
            if (fBold != null) typeface = fBold else setTypeface(null, Typeface.BOLD)
        } else if (fReg != null) typeface = fReg
    }

    private lateinit var micRing: FrameLayout
    private lateinit var micCore: FrameLayout

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(PatternView(this), ViewGroup.LayoutParams(-1, -1))

        val b = dp(28)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.setMargins(dp(22), dp(34), dp(22), dp(30))
        root.addView(scroll, lp)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(0, dp(10), 0, dp(10))
        scroll.addView(card, ViewGroup.LayoutParams(-1, -2))

        card.addView(tv("مساعد فؤاد", 34f, brown, true))
        card.addView(tv("قول: ألو + سمية الشخص", 16f, Color.parseColor("#6B5B4F")).apply {
            setPadding(0, dp(2), 0, dp(16))
        })

        micRing = FrameLayout(this)
        micCore = FrameLayout(this)
        micCore.elevation = dp(6).toFloat()
        micCore.addView(MicView(this), FrameLayout.LayoutParams(dp(66), dp(66), Gravity.CENTER))
        micRing.addView(micCore, FrameLayout.LayoutParams(dp(134), dp(134), Gravity.CENTER))
        micRing.setOnClickListener { toggle() }
        card.addView(micRing, LinearLayout.LayoutParams(dp(176), dp(176)))

        status = tv("", 19f, red, true).apply { setPadding(0, dp(12), 0, dp(4)) }
        card.addView(status)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(MicView(this, green), LinearLayout.LayoutParams(dp(26), dp(26)))
        head.addView(tv("الأشخاص المسجلين:", 20f, brown, true).apply {
            setPadding(dp(8), 0, 0, 0)
        })
        val hlp = LinearLayout.LayoutParams(-1, -2)
        hlp.topMargin = dp(18)
        hlp.bottomMargin = dp(10)
        card.addView(head, hlp)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        card.addView(list, LinearLayout.LayoutParams(-1, -2))

        val add = LinearLayout(this)
        add.orientation = LinearLayout.HORIZONTAL
        add.gravity = Gravity.CENTER
        add.background = shape(green, 40)
        add.elevation = dp(6).toFloat()
        add.setOnClickListener { startActivity(Intent(this, AddContactActivity::class.java)) }
        add.addView(tv("زيد شخص", 22f, Color.WHITE, true))
        val circle = tv("+", 26f, green, true)
        circle.background = oval(Color.WHITE)
        val clp = LinearLayout.LayoutParams(dp(38), dp(38))
        clp.marginStart = dp(12)
        add.addView(circle, clp)
        val alp = LinearLayout.LayoutParams(-1, dp(66))
        alp.topMargin = dp(10)
        card.addView(add, alp)

        card.addView(tv("ولا بالصوت: قول «ألو فؤاد، زيد جهة»", 13f, Color.parseColor("#6B5B4F")).apply {
            setPadding(0, dp(14), 0, 0)
        })

        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toggle() {
        if (VoiceService.on) {
            stopService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
        } else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            startForegroundService(Intent(this, VoiceService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
        }
    }

    private fun addDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val n = EditText(this).apply { hint = "السمية (مثلا: ماما)" }
        val ph = EditText(this).apply {
            hint = "النمرة"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        box.addView(n)
        box.addView(ph)
        AlertDialog.Builder(this)
            .setTitle("شخص جديد")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val name = n.text.toString().trim()
                val num = ph.text.toString().filter { it.isDigit() || it == '+' }
                if (name.isNotEmpty() && num.length >= 8) {
                    prefs.edit().putString(name, num).apply()
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun refresh() {
        val on = VoiceService.on
        micRing.background = oval(Color.parseColor(if (on) "#D8E8DE" else "#F1D3CB"))
        micCore.background = oval(if (on) green else Color.parseColor("#C2412D"))
        status.setTextColor(if (on) green else Color.parseColor("#C2412D"))
        status.text = if (on) "المساعد شاعل\nقول: ألو ماما" else "اضغط باش تشغل المساعد"

        list.removeAllViews()
        val keys = prefs.all.keys.sorted()
        if (keys.isEmpty()) {
            list.addView(tv("ما كاين حتى شخص مسجل", 16f, Color.parseColor("#6B5B4F")))
        }
        for (k in keys) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(10), dp(10), dp(10))
            row.background = shape(Color.parseColor("#F3EBDD"), 18, 2, Color.parseColor("#CFC9A0"))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(tv(k, 22f, brown, true).apply { gravity = Gravity.START })
            col.addView(tv(prefs.getString(k, "") ?: "", 15f, Color.parseColor("#6B5B4F")).apply {
                gravity = Gravity.START
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv("✕", 22f, Color.parseColor("#C2412D"), true).apply {
                setPadding(dp(12), dp(6), dp(6), dp(6))
                setOnClickListener { prefs.edit().remove(k).apply(); refresh() }
            })
            val rlp = LinearLayout.LayoutParams(-1, -2)
            rlp.bottomMargin = dp(8)
            list.addView(row, rlp)
        }
    }
}
